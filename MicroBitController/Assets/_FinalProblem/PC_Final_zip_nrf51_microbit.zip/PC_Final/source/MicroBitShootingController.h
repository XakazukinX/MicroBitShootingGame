#include "mbed.h"
#include "MicroBit.h" 
#define MIN_TIME_DIFF 20
#include "Accelerometer.h"

class MicroBitShootingController :public MicroBitComponent{
    private:

            
    public:
        
};