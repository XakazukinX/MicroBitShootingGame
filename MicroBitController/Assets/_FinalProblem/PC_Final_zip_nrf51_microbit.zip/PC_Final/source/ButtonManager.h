#include "mbed.h"
#include "MicroBit.h" 
#define MIN_TIME_DIFF 20
#include "Accelerometer.h"

class ButtonManager :public MicroBitComponent{
    private:
        Timer yellowButtonChatteringTimer;
        int yellowButtonPrevious;
        int yellowButtonCurrent;
        
        Timer greenButtonChatteringTimer;
        int greenButtonPrevious;
        int greenButtonCurrent;
        
        Timer redButtonChatteringTimer;
        int redButtonPrevious;
        int redButtonCurrent;
    public:
        ButtonManager(MicroBit& mb);
        MicroBit& m_uBit;
        enum ButtonColor; 
        void CheckButton(ButtonColor color ,MicroBitPin& pin,Timer timer,int& p,int& c);
        void ControllerUpdate();
        virtual void idleTick(); 
        virtual void systemTick();
        enum ButtonColor 
        {
            Yellow,
            Green,
            Red,
        };
};