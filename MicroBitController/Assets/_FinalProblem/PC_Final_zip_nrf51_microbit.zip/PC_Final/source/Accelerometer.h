#include "mbed.h"
#include "MicroBit.h" 
#define RightThreshold 400
#define LeftThreshold -400
#define FrontThreshold -600
#define BackThreshold 400
/*
micro:bit ver1.5 is using LSM303AGR for its accelerometer.
https://www.st.com/resource/en/datasheet/lsm303agr.pdf
You cannot use this code for micro:bit ver1.3.
*/
 
const int ACCEL_ADDRESS = 0x19 << 1;
 
class Accelerometer :public MicroBitComponent{
    private:
        I2C i2c;
        int status;
        int read(int axis);  // 0 for X-axis, 1 for Y-axis, 2 for Z-axis
        
        enum AccType;
        int CheckAccValue(AccType acctype);
        enum AccType 
        {
            Acc_X,
            Acc_Y,
            Acc_Z
        };
        
    public:
        Accelerometer(MicroBit& mb);
        MicroBit& m_uBit;
        void init();
        int readX();
        int readY();
        int readZ();
        int getStatus();
        virtual void idleTick();
        virtual void systemTick();
};