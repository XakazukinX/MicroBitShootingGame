#include "mbed.h"
#include "MicroBit.h"
#include "ButtonManager.h"

#define MIN_TIME_DIFF 20

/*MicroBitShootingController* controller;*/
MicroBit uBit; 
int main()
{   
    uBit.serial.baud(57600);
    ButtonManager* bm = new ButtonManager(uBit);
    Accelerometer* acc = new Accelerometer(uBit);

    uBit.addSystemComponent(bm); 
    uBit.addSystemComponent(acc);
    
/*    controller = new MicroBitShootingController();*/
/*    uBit.messageBus.listen(MICROBIT_ID_BUTTON_A, MICROBIT_BUTTON_EVT_DOWN, onButtonA,MESSAGE_BUS_LISTENER_IMMEDIATE);
    uBit.messageBus.listen(MICROBIT_ID_BUTTON_B, MICROBIT_BUTTON_EVT_DOWN, onButtonB,MESSAGE_BUS_LISTENER_IMMEDIATE);*/
    while(1)
    {
/*        controller.ControllerUpdate();*/
/*        uBit.serial.send(a);*//*
        uBit.serial.send("\n");*/
        uBit.sleep(1000);
    }
}
