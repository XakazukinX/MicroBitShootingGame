#include "ButtonManager.h"
#include "MicroBit.h"

#define MIN_TIME_DIFF 20

ButtonManager::ButtonManager(MicroBit& mb):m_uBit(mb){
    
    //タイマー初期化
    yellowButtonChatteringTimer.start();
    greenButtonChatteringTimer.start();
    redButtonChatteringTimer.start();

    //スイッチのステート管理変数初期化
    yellowButtonPrevious = 0;
    yellowButtonCurrent = 1;
    greenButtonPrevious = 0;
    greenButtonCurrent = 1;
    redButtonPrevious = 0;
    redButtonCurrent = 1;
}

//Yellow
MicroBitPin YellowPin_P14(MICROBIT_ID_IO_P14, MICROBIT_PIN_P14, PIN_CAPABILITY_DIGITAL);
//Green
MicroBitPin GreenPin_P12(MICROBIT_ID_IO_P12, MICROBIT_PIN_P12, PIN_CAPABILITY_DIGITAL);
//Red
MicroBitPin RedPin_P13(MICROBIT_ID_IO_P13, MICROBIT_PIN_P13, PIN_CAPABILITY_DIGITAL);


void ButtonManager::ControllerUpdate()
{
    //yellow
    CheckButton(Yellow,YellowPin_P14,yellowButtonChatteringTimer,yellowButtonPrevious,yellowButtonCurrent);
    //green
    CheckButton(Green,GreenPin_P12,greenButtonChatteringTimer,greenButtonPrevious,greenButtonCurrent);
    //red
    CheckButton(Red,RedPin_P13,redButtonChatteringTimer,redButtonPrevious,redButtonCurrent);
}

void ButtonManager::idleTick()
{
}

void ButtonManager::systemTick()
{
    ControllerUpdate();
}



//各ボタンのチャタリングを防止しつつ入力を監視する関数
void ButtonManager::CheckButton(ButtonColor color,MicroBitPin& pin,Timer timer,int& prev,int& current)
{
    prev = current;
    current = pin.getDigitalValue();
    if(prev == 1 && current == 0) {
        int timediff = timer.read_ms();
        if(timediff > MIN_TIME_DIFF) {
            //処理
            switch(color) {
                case Yellow:
                    m_uBit.serial.send("Yellow\n");
                    break;
                case Green:
                    m_uBit.serial.send("Green\n");
                    break;
                case Red:
                    m_uBit.serial.send("Red\n");
                    break;
            }
        }
        timer.reset();
    }
    if(prev == 0 && current == 1) {
        timer.reset();
    }
}
