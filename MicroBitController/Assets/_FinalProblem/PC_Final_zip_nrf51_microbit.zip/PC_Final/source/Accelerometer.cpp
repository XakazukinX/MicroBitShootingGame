#include "MicroBit.h" 
#include "MicroBitConfig.h"
#include "ErrorNo.h"
#include "MicroBitConfig.h"
#include "MicroBitEvent.h"
#include "MicroBitCompat.h"
#include "MicroBitFiber.h"
#include "Accelerometer.h"


Accelerometer::Accelerometer(MicroBit& mb) : i2c(P0_30, P0_0) ,m_uBit(mb) {
    char Data[2];
    Data[0] = 0x20;    // CTRL_REG1_A (20h)
    Data[1] = 0x77;    // 400hz, all xyz channels are enabled
    status = i2c.write(ACCEL_ADDRESS, Data, 2);
 
    Data[0] = 0x23;    // CTRL_REG4_A (23h)
    Data[1] = 0x08;    // 12bit resolution with mode +-2g
    status = i2c.write(ACCEL_ADDRESS, Data, 2);
    
    init();
}


//初期化関数
void Accelerometer::init()
{
    if(!(status & MICROBIT_ACCEL_ADDED_TO_IDLE))
    {
        fiber_add_idle_component(this);
        status |= MICROBIT_ACCEL_ADDED_TO_IDLE;
    }
}
void Accelerometer::idleTick()
{
}

void Accelerometer::systemTick()
{
    CheckAccValue(Acc_X);
    CheckAccValue(Acc_Z);
    //m_uBit.serial.send(readX());
}

int Accelerometer::read(int axis) 
{
    char Data[2];
    int16_t reg = 0x28;
    int16_t value;
    
    if(axis == 0) 
    {
        reg = 0x28;   // for X-axis
    }
    else if(axis == 1) 
    {
        reg = 0x2A;   // for Y-axis
    }
    else if(axis == 2) 
    {
        reg = 0x2C;   // for Z-axis
    }
    
    Data[0] = 0x80 + reg;
    status = i2c.write(ACCEL_ADDRESS, Data, 1, true);
    status = i2c.read(ACCEL_ADDRESS, Data, 2);
    value = Data[1];
    value <<= 8;
    value |= Data[0];
    value >>= 4;       // because data stored in left justified and our resolution is 12bit
    return (int)value;
}
 
int Accelerometer::readX() 
{
    return read(0);
}
 
int Accelerometer::readY() 
{
    return read(1);
}
 
int Accelerometer::readZ() 
{
    return read(2);
}
 
int Accelerometer::getStatus() 
{
    return status;
}


//各軸の値を閾値を超えていたら更新する関数
int Accelerometer::CheckAccValue(AccType acctype)
{
    switch(acctype){
        case Acc_X:
            int Xvalue = readX();
            if(Xvalue>RightThreshold){
                m_uBit.serial.send("Right\n");            
            }
            else if(Xvalue <LeftThreshold){
                m_uBit.serial.send("Left\n");
            }
            break;
        case Acc_Y:            
            break;    
        case Acc_Z:
            int Zvalue = readZ();
/*            m_uBit.serial.send(Zvalue);            
            m_uBit.serial.send("\n");            */
            if(Zvalue<FrontThreshold){
                m_uBit.serial.send("Front\n");            
            }
            else if(Zvalue >BackThreshold){
                m_uBit.serial.send("Back\n");
            }
            break;
    }
    
    return -1;
}